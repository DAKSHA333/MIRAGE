# MIRAGE V1

A working local prototype of Team Nexora's AI privacy firewall. Built from the supplied AWS Innovation Challenge presentation, with a deliberately small first release.

## Open the prototype

With Node.js installed, double-click **START-MIRAGE.cmd**, or run:

```sh
npm start
```

Then open http://127.0.0.1:4173. There are no dependencies to install. The local server only serves static files and binds to your own computer. You can also run the same workspace as a Chrome extension without Node.js.

## Install the Chrome extension

1. Open `chrome://extensions` in Chrome.
2. Turn on **Developer mode**.
3. Click **Load unpacked** and select this project's **extension** folder (the folder containing `manifest.json`).
4. Pin MIRAGE and click its toolbar button to open the workspace.

The extension requests no host, storage, or account permissions. It uses a Manifest V3 service worker to open its workspace. See the official [manifest documentation](https://developer.chrome.com/docs/extensions/reference/manifest) and [action API](https://developer.chrome.com/docs/extensions/reference/api/action).

## Two-minute demo

1. Click **Personal details**, then **Scan & mask**.
2. Review the highlighted tokens and scan findings. The original identifiers should be absent from the preview.
3. Click **Copy masked prompt** and paste into your preferred chatbot. Ask it to keep MIRAGE tokens unchanged.
4. Paste its response into **AI reply with tokens**, then click **Restore details**.
5. For a demo without a chatbot, use **Try a sample reply**. This is canned local text, clearly labeled, not an AI response.
6. Click **Secret key**, then scan. The workspace blocks copying until you remove the secret and scan again.
7. Use **Clear session** to discard the current prompt, reply, and token map.

## What V1 does

- Masks PAN, Aadhaar-shaped numbers, UPI handles, IFSC, email, Indian mobile numbers, and names immediately following supported introductions.
- Checks Aadhaar with Verhoeff. It also masks Aadhaar-shaped values that fail the checksum as a precaution.
- Checks PAN, UPI and IFSC formats only. These do not have a general checksum here, and no identity or bank lookup takes place.
- Allows literal custom private terms, one per line, including names in other languages and addresses.
- Blocks recognized API key patterns, labeled passwords/tokens/OTPs, private keys, and likely payment credentials. Card detection uses Luhn or a card label.
- Restores exact tokens locally using a per-scan map and randomly generated scan identifier. Repeated values share a token.
- Invalidates prior output when the original prompt or custom terms change.
- Leaves unknown tokens unchanged and reports them.
- Renders all user text as plain text, never HTML.

## Scope and limits

This is a manual workspace, not automatic interception of ChatGPT or Gemini. It cannot stop you sending sensitive text directly in another tab. It blocks the **Copy masked prompt** action in this workspace when its rules detect secrets. It does not guarantee detection of every secret or personal detail.

Names use a limited English introduction heuristic, not a general language model. Addresses, international phone formats, unlabeled or obfuscated secrets, documents, images and attachments are not comprehensively detected. Add custom terms and review the preview. Health information itself stays in the prompt unless you add it as a custom term.

The token map exists in this tab's JavaScript memory only. There is no persistent or encrypted vault, database, telemetry, or AWS integration in V1. Closing/reloading the tab, starting another scan, editing input, or clearing the session discards the mapping; keep the same tab and scan until you restore your reply. Clearing the map is not a guarantee of forensic memory erasure. Copying places text on the operating system clipboard, which the app does not erase. Copying a restored reply includes original personal details.

AWS Comprehend, Cognito, Lambda, DynamoDB and Bedrock Guardrails from the deck are future work. No external service is called by this prototype. Browser cache/back navigation behavior is not a secure deletion guarantee.

## Development

```sh
npm test
npm start
```

`extension/engine.js` contains detection, masking and restoration. `extension/app.js` manages the UI and in-memory session. `extension/index.html` and `styles.css` are shared by the extension and local preview. `server.mjs` is a small development server. There is no build step or third-party runtime dependency.

## Next versions

1. Improve detection using a labeled test corpus, more phone formats, and local name/address detection.
2. Add explicit review-and-send integration for ChatGPT and Gemini with provider-specific tests.
3. Add optional AWS processing only after defining redaction, user consent, logging controls, and an evaluated privacy boundary.

The supplied deck is product context. Statements about a future hackathon or having no prototype do not override the request to build this V1.
