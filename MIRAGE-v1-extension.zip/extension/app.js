import { scan, restore } from './engine.js';
const $ = id => document.getElementById(id);
const prompt = $('prompt');
let result = null;
let restoredText = null;
let toastTimer;
function announce(message) { $('announcement').textContent = message; }
function toast(message) { $('toast').textContent = message; clearTimeout(toastTimer); toastTimer = setTimeout(() => { $('toast').textContent = ''; }, 4200); }
function resetResult() {
  if (result) result.vault.clear();
  result = null; restoredText = null;
  $('empty-preview').hidden = false; $('masked').hidden = true; $('masked').replaceChildren(); $('blocked-view').hidden = true;
  $('result-badge').textContent = 'Awaiting scan'; $('result-badge').className = 'badge';
  for (const id of ['copy', 'restore', 'demo-reply', 'copy-restored']) $(id).disabled = true;
  $('reply').value = ''; $('restored').textContent = 'Your restored reply will appear here.';
  $('restore-note').textContent = 'No AI request is made by this prototype.';
  $('findings').replaceChildren(); $('finding-count').textContent = '0';
  const message = document.createElement('p'); message.className = 'muted small'; message.textContent = 'Checks for Indian IDs, contact details, common secret patterns, and names in introductions.'; $('findings').append(message);
  $('scan-summary').textContent = 'Your next scan appears here';
  $('preview-note').textContent = 'Review every preview. Local rules can miss personal data.';
}
function updateInput() { resetResult(); $('char-count').textContent = `${prompt.value.length.toLocaleString()} / 30,000`; }
prompt.addEventListener('input', updateInput);
$('custom').addEventListener('input', updateInput);
$('sample-personal').addEventListener('click', () => {
  prompt.value = "Hi, I'm Priya Nair. My PAN is ABCDE1234F and my number is 98450 12345. Please draft an email to hod.cse@pu.edu.in asking for a meeting about my project.";
  $('custom').value = ''; updateInput(); prompt.focus(); toast('Illustrative sample loaded. Scan it to see the mask.');
});
$('sample-secret').addEventListener('click', () => {
  prompt.value = 'Help me debug my app. My API key is sk-demo-1234567890abcdefghijklmnop and my password is demo-password-123.';
  $('custom').value = ''; updateInput(); prompt.focus(); toast('Synthetic secret example loaded.');
});
function renderMasked(text) {
  const output = $('masked'); output.replaceChildren();
  let cursor = 0;
  for (const m of text.matchAll(/\[MG_[A-Z0-9]+_[A-Z]+_\d+\]/g)) {
    output.append(document.createTextNode(text.slice(cursor, m.index)));
    const mark = document.createElement('mark'); mark.textContent = m[0]; output.append(mark); cursor = m.index + m[0].length;
  }
  output.append(document.createTextNode(text.slice(cursor)));
}
$('scan').addEventListener('click', () => {
  resetResult();
  if (!prompt.value.trim()) { toast('Add a prompt before scanning.'); prompt.focus(); return; }
  try {
    const bytes = crypto.getRandomValues(new Uint8Array(4));
    const id = Array.from(bytes, n => n.toString(16).padStart(2, '0')).join('').toUpperCase();
    result = scan(prompt.value, $('custom').value.split('\n'), id);
  } catch (error) { toast(error.message); announce(error.message); return; }
  $('empty-preview').hidden = true;
  $('finding-count').textContent = result.findings.length;
  $('findings').replaceChildren();
  const groups = new Map();
  for (const f of result.findings) { const k = `${f.type}:${f.note}`; if (!groups.has(k)) groups.set(k, { ...f, count: 0 }); groups.get(k).count++; }
  for (const f of groups.values()) {
    const chip = document.createElement('div'); chip.className = `finding${f.blocked ? ' secret' : ''}`;
    const label = document.createElement('strong'); label.textContent = `${f.blocked ? 'Blocked' : 'Masked'} · ${f.label} × ${f.count}`;
    if (result.blocked && !f.blocked) label.textContent = `Detected · ${f.label} × ${f.count}`;
    const detail = document.createElement('span'); detail.textContent = f.note; chip.append(label, detail); $('findings').append(chip);
  }
  if (!result.findings.length) { const p = document.createElement('p'); p.className = 'small muted'; p.textContent = 'No matches found. This does not guarantee the text is free of personal data. Add private terms above if needed.'; $('findings').append(p); }
  $('result-badge').textContent = result.blocked ? 'Secret detected' : (result.findings.length ? 'Ready to review' : 'No matches');
  $('result-badge').className = `badge ${result.blocked ? 'red' : 'green'}`;
  $('scan-summary').textContent = result.blocked ? 'Remove secrets and scan again' : `${result.vault.size} unique details masked · Review before copying`;
  if (result.blocked) { $('blocked-view').hidden = false; $('preview-note').textContent = 'No masked prompt is available while a secret is detected.'; announce('Secret detected. Copy blocked. Remove the secret and scan again.'); }
  else { $('masked').hidden = false; renderMasked(result.masked); $('copy').disabled = false; $('restore').disabled = false; $('demo-reply').disabled = false; announce(`Scan complete. ${result.findings.length} matches found. Review the preview before copying.`); }
});
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); toast('Copied to clipboard.'); }
  catch { toast('Clipboard unavailable. Select the visible text and copy it manually.'); }
}
$('copy').addEventListener('click', () => { if (result && !result.blocked) copyText(result.masked); });
$('reply').addEventListener('input', () => { restoredText = null; $('copy-restored').disabled = true; $('restored').textContent = 'Your restored reply will appear here.'; $('restore-note').textContent = 'Ready to restore using this scan’s token map.'; });
$('demo-reply').addEventListener('click', () => {
  if (!result || result.blocked) return;
  const tokens = [...result.vault.keys()];
  $('reply').value = tokens.length ? `This is a sample reply for testing restoration (not generated by AI).\n\nI can help draft your message using these details:\n${tokens.join('\n')}\n\nThank you for sharing the context.` : 'This is a sample reply. No personal details were detected, so there are no tokens to restore.';
  restoredText = null; $('copy-restored').disabled = true; $('restored').textContent = 'Your restored reply will appear here.';
  $('restore-note').textContent = 'Sample reply loaded. Click Restore details.'; toast('Sample reply loaded. This is a local demonstration.');
});
$('restore').addEventListener('click', () => {
  if (!result || result.blocked) return;
  if (!$('reply').value.trim()) { toast('Paste an AI reply first.'); $('reply').focus(); return; }
  const restored = restore($('reply').value, result.vault);
  restoredText = restored.text; $('restored').textContent = restored.text; $('copy-restored').disabled = false;
  $('restore-note').textContent = restored.unknown.length ? `${restored.unknown.length} unknown token(s) left unchanged. Use the same scan and exact tokens.` : 'Restored locally. Copying this reply includes the original details.';
  announce(restored.unknown.length ? 'Reply restored with unknown tokens left unchanged.' : 'Reply restored on this device.');
});
$('copy-restored').addEventListener('click', () => { if (restoredText !== null) copyText(restoredText); });
$('clear').addEventListener('click', () => { prompt.value = ''; $('custom').value = ''; updateInput(); toast('Session cleared. Your token map has been discarded.'); prompt.focus(); });
window.addEventListener('pagehide', () => { if (result) result.vault.clear(); });
